<?php

//category_fetch.php

include('database_connection.php');
$query="select * from category group by category_name";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$output='<table class="table table-bordered table-striped table-hover" id="example">

<thead>
<tr>
<th>ID</th>
<th>CATEGORY NAME</th>
<th hidden>STATUS</th>
<th><center>EDIT</center></th>
<th><center>STATUS</center></th>
</tr>
</thead>';
foreach($result as $row)
{
	$status = '';
	if($row["category_status"] == 'active')
	{
		$status = '<label class="btn btn-success btn-sm active">Active</label>';
	}
	else
	{
		$status = '<label class="btn btn-danger btn-sm active">Inactive</label>';
	}
	$output .= '<tr>
	<td>'.$row['category_id'].'</td>
	<td>'.$row['category_name'].'</td>
	<td hidden>'.$status.'</td>
	<td><center><button type="button" name="update" id="'.$row["category_id"].'" class="btn btn-outline btn-primary btn-sm active update"><i class="glyphicon glyphicon-edit"></i>EDIT</button></center></td>
	<td><center><label type="label" name="update" id="'.$row["category_id"].'" class=" delete"
	data-status="'.$row["category_status"].'">'.$status.'</label></center></td>
	</tr>

	';
}

$output.='</tbody>
</table>';
echo($output);
?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#example').DataTable({
			responsive: true,
			"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]

		});
	});
</script>