	<?php

//category_action.php

	include('database_connection.php');

	if(isset($_POST['btn_action']))
	{
		if($_POST['btn_action'] == 'Add')
		{
			$c_name=$_POST["c_name"];
			$vbl='insrt';
			$active="active";
			for($i=0;$i<count($c_name);$i++)
			{
				$query="SELECT * FROM category WHERE category_name=:cat_name";
				$statement=$connect->prepare($query);
				$statement->execute(array(":cat_name"=>$c_name[$i]));
				$result=$statement->rowCount();
			}
			if($result>0)
			{
				echo "Already Exits";
			}
			else
			{
				for($i=0;$i<count($c_name);$i++)
				{
					$query = "call cat_pro('".$vbl."','".null."',:cat_name,'".null."')";
					$statement = $connect->prepare($query);
					$statement->execute(array(':cat_name' => $c_name[$i]));
					$result = $statement->fetchAll();
				}
				if($result)
				{
					echo 'Successfully Category Name Added';
				}
			}
		}

		if($_POST['btn_action'] == 'fetch_single')
		{
			$query = "SELECT * FROM category WHERE category_id = :category_id";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					':category_id'	=>	$_POST["category_id"]
				)
			);
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output['category_name'] = $row['category_name'];
				$output['cat_status'] = $row['category_status'];
			}
			echo json_encode($output);
		}

		if($_POST['btn_action'] == 'Edit')
		{
			$cat_id=$_POST["cat_id"];
			$cat_name=$_POST["c_name"];
			$cat_status=$_POST['cat_status'];
			$vbl1='upd';
			for($i=0;$i<count($cat_id);$i++)
			{
				$query = "call cat_pro('".$vbl1."',:cat_id,:cat_name,:cat_status)";
				$statement = $connect->prepare($query);
				$statement->execute(array(':cat_id' => $cat_id[$i], ':cat_name'=>$cat_name[$i], ':cat_status'=>$cat_status[$i]
			)
			);
				$result = $statement->fetchAll();
			}
			if(isset($result))
			{
				echo 'Successfully Category Name Updated';
			}
		}
		if($_POST['btn_action'] == 'delete')
		{
			$status = 'active';
			if($_POST['status'] == 'active')
			{
				$status = 'inactive';	
			}
			$query = "
			UPDATE category 
			SET category_status = :category_status 
			WHERE category_id = :category_id
			";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					':category_status'	=>	$status,
					':category_id'		=>	$_POST["category_id"]
				)
			);
			$result = $statement->fetchAll();
			if(isset($result))
			{
				echo 'Succcessfully Category status change to ' . $status;
			}
		}


		if($_POST['btn_action']=='exist')
		{
			$query="SELECT * FROM category WHERE category_name=:cat_name";
			$statement=$connect->prepare($query);
			$statement->execute(array(":cat_name"=>$_POST['category_name']));
			$result=$statement->rowCount();
			if($result>0)
			{
				echo "Already Exits";
			}
			else
			{
				echo "available";
			}
		}
	}

	?>