<?php
include('database_connection.php');
if(isset($_POST['save_invoice']))
{
	$print_in=$_POST['invoice'];
	$query = "call join_product_orderproduct_order('".$vbl='fetch_all_data'."',:order_id)";
	$statement = $connect->prepare($query);
	$statement->execute(array(":order_id"=>$print_in));
	$result = $statement->fetchAll();
	$total='';
	$tax='';
	$gtotal='';
	$order_name='';
	$order_mobile='';
	$address='';
	$orderid='';
	$mode='';
	foreach($result as $row)
	{
		 $order_name = $row["inventory_order_name"];
		 $order_mobile = $row["inventory_order_mobile"];
		 $address=$row["inventory_order_address"];
		 $orderid=$row["inventory_order_id"];
		 $mode=$row["payment_status"];
	}
	$i=1;
}

require('fpdf17/fpdf.php');
$pdf = new FPDF('p','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',20);
$pdf->Cell(195,25,'',0,1);
$pdf->Cell(130, 7,'PC-WORLD',0,0);
$pdf->Cell(65,7,'Invoice',0,1);
$pdf->Cell(195,10,'',0,1);

$pdf->SetFont('Arial','',14);
$pdf->Cell(130,5,'Customer Name  -: '.$order_name,0,0);
$pdf->Cell(65 ,5,'Date-:  		  '.date('d-m-yy'),0,1);
$pdf->Cell(195,3,'',0,1);

$pdf->Cell(130,5,'Mobile                  -: '.$order_mobile,0,0);
$pdf->Cell(65 ,5,'Invoice No-:    '.rand(10000,50000),0,1);
$pdf->Cell(195,3,'',0,1);

$pdf->Cell(130,5,'Address               -: '.$address,0,0);
$pdf->Cell(65,5,'Order-ID-:       '.$orderid,0,1);
$pdf->Cell(195,3,'',0,1);

$pdf->Cell(130,5,'Payment-Mode    -:'.$mode,0,1);

$pdf->Cell(195,40,'',0,1);

$pdf->SetFont('Arial','B',14);
$pdf->Cell(20 ,10,'SNO',1,0);
$pdf->Cell(90 ,10,'Product Name',1,0);
$pdf->Cell(30 ,10,'Quantity',1,0);
$pdf->Cell(50  ,10,'Price',1,1);

$pdf->SetFont('Arial','',12);
foreach ($result as $row) 
{
	$total=$row["inventory_total"];
	$tax=$row["inventory_tax"];
	$gtotal=$row["inventory_order_total"];
	$pdf->Cell(20 ,9,$i++,1,0);
	$pdf->Cell(90 ,9,$row["brand_name"]."   ".$row["product_name"],1,0);
	$pdf->Cell(30 ,9,$row["quantity"],1,0);
	$pdf->Cell(50  ,9,$row["price"],1,1);
}

$pdf->SetFont('Arial','B',14);
$pdf->Cell(140 ,9,'Total',1,0);

$pdf->SetFont('Arial','',12);
$pdf->Cell(50, 9,$total,1,1);

$pdf->SetFont('Arial','B',14);
$pdf->Cell(140 ,9,'Tax 18%',1,0);

$pdf->SetFont('Arial','',12);
$pdf->Cell(50, 9,$tax,1,1);

$pdf->SetFont('Arial','B',14);
$pdf->Cell(140 ,10,'Grand Total',1,0);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(50  ,10,$gtotal,1,1);

$pdf->SetFont('Arial','B',14);
$pdf->Cell(190,50,'',0,1);

$pdf->Cell(190,8,'Signature',0,1,0);




$pdf->Output();
?>