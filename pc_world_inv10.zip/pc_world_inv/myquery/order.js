
	$(document).ready(function(){
		$('#inventory_order_date').datepicker({
			dateFormat: "yy-mm-dd",
			autoclose: true
		});

		$(document).on('click', '.update', function(){
			var inventory_order_id = $(this).attr("id");
			var btn_action = 'fetch_single';
			$.ajax({
				url:"order_action.php",
				method:"POST",
				data:{inventory_order_id:inventory_order_id, btn_action:btn_action},
				dataType:"json",
				success:function(data)
				{
					$('#orderModal').modal('show');
					$('#inventory_order_name').val(data.inventory_order_name);
					$('#inventory_order_date').val(data.inventory_order_date);
					$('#inventory_order_address').val(data.inventory_order_address);
					$('#span_product_details').html(data.product_details);
					$('#payment_status').val(data.payment_status);
					$('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Order");
					$('#inventory_order_id').val(inventory_order_id);
					$('#action').val('Edit');
					$('#btn_action').val('Edit');
				}
			})
		});

		$(document).on('click','.view',function(){
			
			var viewdata=$(this).attr("id");
			var btn_action='view_id';
			$.ajax({
				url:"order_action.php",
				method:"POST",
				data:{btn_action:btn_action,viewdata:viewdata},
				dataType:"json",
				success:function(data)
				{
					$('#viewModal').modal();
					$('.order_id').html(viewdata);
					$('.cusname').html(data.customer);
					$('.total_amount').html(data.total_amt);
					$('.payment').html(data.payment_status);
					$('.order_status').html(data.order_status);
					$('.order_date').html(data.order_date);
					$('.created_by').html(data.created);
				}
			});
		});

		$(document).on('click', '.delete', function(){
			var inventory_order_id = $(this).attr("id");
			var status = $(this).data("status");
			var btn_action = "delete";
			if(confirm("Are you sure you want to change status?"))
			{
				$.ajax({
					url:"order_action.php",
					method:"POST",
					data:{inventory_order_id:inventory_order_id, status:status, btn_action:btn_action},
					success:function(data)
					{
						$('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
						//orderdataTable.ajax.reload();
					}
				})
			}
			else
			{
				return false;
			}
		});


		$('#category_id').change(function(){
			var category_id = $('#category_id').val();
			var btn_action = 'load_brand';
			$.ajax({
				url:"demo_action.php",
				method:"POST",
				data:{category_id:category_id, btn_action:btn_action},
				success:function(data)
				{
					$('#brand_id').html(data);
				}
			});
		});

		$('#brand_id').change(function(){
			var brand_id = $('#brand_id').val();
			var btn_action = 'brand_data';
			$.ajax({
				url:"demo_action.php",
				method:"POST",
				data:{brand_id:brand_id, btn_action:btn_action},
				success:function(data)
				{
					$('#product_id').html(data);
				}
			});
		});
		$(document).on('change','#product_id',function(){
			var id=$(this).val();
			var btn_action='amount';

			$.ajax({
				url:"new.php",
				method:"POST",
				dataType:"json",
				data:{id:id},
				success:function(data)
				{
					$('#pro_id').val(id);
					$('#p_amount').val(data.pro_id);
					alert("Quantity-:"+" "+data.qty+" "+"are available");

				}
			})
		});

		$('#add_button').click(function(){
			$('#orderModal').modal('show');
			$('#order_form')[0].reset();
			$('.modal-title').html("<i class='fa fa-plus'></i> Create Order");
			$('#action').val('Add');
			$('#btn_action').val('Add');
			$('#span_product_details').html('');
			add_product_row();
		});

		var count = 0;
		$(document).on('click','#add_btn',function(){
			var pro_id=$('#pro_id').val();
			var product_name=$('#product_id :selected').text();
			var qty=$('#qty').val();
			var total=$('#total').val();
			var i=count++;
			if(pro_id==''||product_name=='Select Product'||qty=='--Select--')
			{
				alert('All Field Required');
				return false
			}
			$('#add_tab').append('<tr id="'+i+'">'+
				'<td>'+i+'</td>'+
				'<td id="pro_id" class="pro_id '+i+'">'+pro_id+'</td>'+
				'<td id="product_id" class="product_id '+i+'">'+product_name+'</td>'+
				'<td id="qty" class="qty '+i+'">'+qty+'</td>'+
				'<td id="total" class="total '+i+'">'+total+'</td>'+
				'<td ><a href="javascript:void(0)" class="remCF">Remove</a></td>'+
				'</tr>'
				);
			plus();
			$('#category_id')[0].selectedIndex=0;
			$('#brand_id')[0].selectedIndex=0;
			$('#pro_id')[0].selectedIndex=0;
			$("#product_id")[0].selectedIndex = 0;
			$("#qty")[0].selectedIndex = 0;

		});

		$("#add_tab").on('click', '.remCF', function() {
			$(this).parent().parent().remove();
			minus();
		});

		function plus()
		{
			var total_amount = 0;
			var tax=0;
			var g_total=0;
		// iterate through each td based on class and add the values
		$(".total").each(function() {

			var value = $(this).text();
		    // add only if the value is number
		    if(!isNaN(value) && value.length != 0) {
		    	total_amount += parseFloat(value);
		    	tax += parseFloat(value)*18/100;
		    	g_total = parseFloat(total_amount+tax);

		    }
		});
		$('#total_amount').val(total_amount);
		$('#tax_amount').val(tax);
		$('#grand_total').val(g_total);
	}
	function minus()
	{
		var sum = 0;
		// iterate through each td based on class and add the values
		$(".total").each(function() {

			var value = $(this).text();
		    // add only if the value is number
		    if(!isNaN(value) && value.length != 0) {
		    	sum - parseFloat(value);
		    }
		});
		$('#grand_total').val(sum);
	}

	$('#qty').on('change',function(){

		var p_amount=parseFloat(document.getElementById('p_amount').value);
		var qty=parseFloat(document.getElementById('qty').value);
		var total=parseFloat(document.getElementById('total').value=p_amount*qty);
		//var g_total=parseFloat(document.getElementById('grand_total').value=total+g_total);
	});

	$(document).on('click','#action',function(){

		var btn_action=$('#btn_action').val();
		var inventory_order_name=$('#inventory_order_name').val();
		var inventory_order_mobile=$('#inventory_order_mobile').val();
		var inventory_order_date=$('#inventory_order_date').val();
		var inventory_order_address=$('#inventory_order_address').val();
		var payment_status=$('#payment_status').val();
		var total_amount=$('#total_amount').val();
		var tax_amount=$('#tax_amount').val();
		var grand_total=$('#grand_total').val();
		var pro_id=[];
		var product_name=[];
		var qty=[];
		var total=[];
		var tax=[];

		$('.pro_id').each(function(){
			pro_id.push($(this).text());
		});

		$('.product_id').each(function(){
			product_name.push($(this).text());
		});
		$('.qty').each(function(){
			qty.push($(this).text());
		});
		$('.total').each(function(){
			total.push($(this).text());
		});
		
		if(inventory_order_name=='' || inventory_order_mobile == '' || inventory_order_date == '' || 
			inventory_order_address == '')
		{
			alert('All Field Required');
			return false;
		}

		$.ajax({

			url:"order_action.php",
			type:"POST",
			data:{btn_action:btn_action, inventory_order_name:inventory_order_name,

				inventory_order_mobile:inventory_order_mobile, inventory_order_date:inventory_order_date,

				inventory_order_address:inventory_order_address, payment_status:payment_status,

				total_amount:total_amount, tax_amount:tax_amount,

				grand_total:grand_total, pro_id:pro_id, product_name:product_name,

				qty:qty, total:total
			},
			success:function(data)
			{
				$('#order_form')[0].reset();
				//$('#orderModal').modal('hide');
				$("#myModal").modal();
				$('#alert_action').fadeIn().html('<div class="alert alert-success">Order Created...</div>');
				$('#invoice').val(data);
				$('#action').attr('disabled', false);
				orderdataTable.ajax.reload();
			}
		});
	});

	$(document).on('click', '.update', function(){
		var inventory_order_id = $(this).attr("id");
		var btn_action = 'fetch_single';
		$.ajax({
			url:"order_action.php",
			method:"POST",
			data:{inventory_order_id:inventory_order_id, btn_action:btn_action},
			dataType:"json",
			success:function(data)
			{
				$('#orderModal').modal('show');
				$('#inventory_order_name').val(data.inventory_order_name);
				$('#inventory_order_date').val(data.inventory_order_date);
				$('#inventory_order_address').val(data.inventory_order_address);
				$('#span_product_details').html(data.product_details);
				$('#payment_status').val(data.payment_status);
				$('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Order");
				$('#inventory_order_id').val(inventory_order_id);
				$('#action').val('Edit');
				$('#btn_action').val('Edit');
			}
		})
	});

	$(document).on('click', '.delete', function(){
		var inventory_order_id = $(this).attr("id");
		var status = $(this).data("status");
		var btn_action = "delete";
		if(confirm("Are you sure you want to change status?"))
		{
			$.ajax({
				url:"order_action.php",
				method:"POST",
				data:{inventory_order_id:inventory_order_id, status:status, btn_action:btn_action},
				success:function(data)
				{
					$('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
					orderdataTable.ajax.reload();
				}
			})
		}
		else
		{
			return false;
		}
	});


});