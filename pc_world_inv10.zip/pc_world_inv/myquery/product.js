 $(document).ready(function(){

        load_data();

        $('#add_button').click(function(){
            $('#productModal').modal('show');
            $('#product_form')[0].reset();
            $('.modal-title').html("<i class='fa fa-plus'></i> Add Product");
            $('#action').val("Add");
            $('#btn_action').val("Add");
        });

        $(document).on('change','#category_id',function(){
            var category_id = $('#category_id').val();
            var btn_action = 'load_brand';
            $.ajax({
                url:"product_action.php",
                method:"POST",
                data:{category_id:category_id, btn_action:btn_action},
                success:function(data)
                {
                    $('#brand_id').html(data);
                }
            });
        });

        $(document).on('submit', '#product_form', function(event){
            event.preventDefault();
            $('#action').attr('disabled', 'disabled');
            var form_data = $(this).serialize();
            $.ajax({
                url:"product_action.php",
                method:"POST",
                data:form_data,
                success:function(data)
                {
                     load_data();
                    $('#product_form')[0].reset();
                    $('#productModal').modal('hide');
                    $('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
                    $('#action').attr('disabled', false);

                }
            })
        });

        $(document).on('click', '.view', function(){
            var product_id = $(this).attr("id");
            var btn_action = 'product_details';
            $.ajax({
                url:"product_action.php",
                method:"POST",
                data:{product_id:product_id, btn_action:btn_action},
                success:function(data){
                    $('#productdetailsModal').modal('show');
                    $('#product_details').html(data);
                }
            })
        });

        $(document).on('click', '.update', function(){
            var product_id = $(this).attr("id");
            var btn_action = 'fetch_single';
            $.ajax({
                url:"product_action.php",
                method:"POST",
                data:{product_id:product_id, btn_action:btn_action},
                dataType:"json",
                success:function(data){
                    $('#productModal').modal('show');
                    $('#category_id').val(data.category_id);
                    $('#brand_id').html(data.brand_select_box);
                    $('#brand_id').val(data.brand_id);
                    $('#product_name').val(data.product_name);
                    $('#product_description').val(data.product_description);
                    $('#product_quantity').val(data.product_quantity);
                    $('#product_unit').val(data.product_unit);
                    $('#product_base_price').val(data.product_base_price);
                    $('#product_tax').val(data.product_tax);
                    $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Product");
                    $('#product_id').val(product_id);
                    $('#action').val("Update");
                    $('#btn_action').val("Edit");
                    load_data();
                }
            })
        });

        $(document).on('click', '.delete', function(){
            var product_id = $(this).attr("id");
            var status = $(this).data("status");
            var btn_action = 'delete';
            if(confirm("Are you sure you want to change status?"))
            {
                $.ajax({
                    url:"product_action.php",
                    method:"POST",
                    data:{product_id:product_id, status:status, btn_action:btn_action},
                    success:function(data){
                        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
                       // productdataTable.ajax.reload();
                       load_data();
                    }
                });
            }
            else
            {
                return false;
            }
        });

    });

    function load_data(view)
    {
        $.ajax({

            url:"product_fetch.php",
            type:"POST",
            data:{view:view},
            success:function(data)
            {
                $('#show_table').html(data);
            }
        });
    }