$(document).ready(function(){
		load_data();

		$('.container').addClass('container-loaded');

	$(document).ready(function(){
		var i=1;
		$('#add').click(function(){

			var item=i++;
			var cat_name=$('#category_name').val();
			var cat_id=$('#category_id').val();
			var cat_status=$('#cat_status').val();
			if(cat_name=='')
			{
				alert('All Field Required');
				return false;
			}
			$('#add_tab').append('<tr class="tab" id="'+item+'">'+
				'<td>'+item+'</td>'+
				'<td hidden id="category_id" class="category_id '+item+'">'+cat_id+'</td>'+
				'<td id="category_name" class="category_name '+item+'">'+cat_name+'</td>'+
				'<td id="cat_status" class="cat_status '+item+'">'+cat_status+'</td>'+
				'<td ><a href="javascript:void(0)" class="remCF">Remove</a></td>'+
				'</tr>');
		});
		$("#add_tab").on('click', '.remCF', function() {
			$(this).parent().parent().remove();
		});

		$('#save').click(function(){
			var btn_action=$('#btn_action').val();
			var cat_id=[];
			var c_name=[];
			var cat_status=[];
			$('.category_name').each(function(){
				c_name.push($(this).text());
			});
			$('.category_id').each(function(){
				cat_id.push($(this).text());
			});
			$('.cat_status').each(function(){
				cat_status.push($(this).text());
			});
			$.ajax({
				url:"category_action.php",
				type:"POST",
				data:{btn_action:btn_action,cat_id:cat_id,c_name:c_name,cat_status:cat_status},
				success:function(data)
				{
					$('#category_form')[0].reset();
					$('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
					//alert(data);
					load_data();
					$('#tab').text('');
				}
			});
		});
	});

	$(document).on('click', '.update', function(){
		$('#btn_action').val('Edit');
		var category_id = $(this).attr("id");
		var btn_action = 'fetch_single';
		$.ajax({
			url:"category_action.php",
			method:"POST",
			dataType:"json",
			data:{category_id:category_id, btn_action:btn_action},
			success:function(data)
			{
				$('#categoryModal').modal('show');
				$('#category_name').val(data.category_name);
				$('#cat_status').val(data.cat_status);
				$('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Category");
				$('#category_id').val(category_id);
				load_data();
				$('#save').val("Edit");
			}
		})
	});

	function load_data(view)
	{
		$.ajax({
			url:"category_fetch.php",
			type:"POST",
			data:{view:view},
			success:function(data)
			{
				$('#view_record').html(data);
			}
		});
	}

	$(document).on('click', '.delete', function(){
		var category_id = $(this).attr('id');
		var status = $(this).data("status");
		var btn_action = 'delete';
		if(confirm("Are you sure you want to change status?"))
		{
			$.ajax({
				url:"category_action.php",
				method:"POST",
				data:{category_id:category_id, status:status, btn_action:btn_action},
				success:function(data)
				{
					$('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
					load_data();
				}
			})
		}
		else
		{
			return false;
		}
	});
});