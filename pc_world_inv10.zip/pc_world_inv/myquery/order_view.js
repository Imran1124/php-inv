$(document).ready(function(){
		$('#print_by').click(function(){
			$('#myModal').modal();
		});

		$(document).on('click','.view',function(){
			
			var viewdata=$(this).attr("id");
			var btn_action='view_id';
			$.ajax({
				url:"order_action.php",
				method:"POST",
				data:{btn_action:btn_action,viewdata:viewdata},
				dataType:"json",
				success:function(data)
				{
					$('#viewModal').modal();
					$('.order_id').html(viewdata);
					$('.cusname').html(data.customer);
					$('.total_amount').html(data.total_amt);
					$('.payment').html(data.payment_status);
					$('.order_status').html(data.order_status);
					$('.order_date').html(data.order_date);
					$('.created_by').html(data.created);
				}
			});
		});

		$(document).on('click','#action',function(){

			var btn_action=$('#btn_action').val();
			var inventory_order_name=$('#inventory_order_name').val();
			var inventory_order_date=$('#inventory_order_date').val();
			var inventory_order_address=$('#inventory_order_address').val();
			var payment_status=$('#payment_status').val();
			var grand_total=$('#grand_total').val();
			var pro_id=[];
			var product_name=[];
			var qty=[];
			var total=[];
			var tax=[];

			$('.pro_id').each(function(){
				pro_id.push($(this).text());
			});

			$('.product_id').each(function(){
				product_name.push($(this).text());
			});
			$('.qty').each(function(){
				qty.push($(this).text());
			});
			$('.total').each(function(){
				total.push($(this).text());
			});
			// $('.tax').each(function(){
			// 	tax.push($(this).val());
			// });

			$.ajax({

				url:"order_action.php",
				type:"POST",
				data:{btn_action:btn_action,inventory_order_name:inventory_order_name,inventory_order_date:inventory_order_date,
					inventory_order_address:inventory_order_address,payment_status:payment_status,grand_total:grand_total,pro_id:pro_id,product_name:product_name,
					qty:qty,total:total},
					success:function(data)
					{
						alert(data);
					}
				});
		});
	});