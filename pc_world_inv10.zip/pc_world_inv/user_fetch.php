<?php
include('database_connection.php');
$query="select * from user_details order by user_id";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
	$output='<table class="table table-bordered table-striped table-hover" id="example">

<thead>
<tr>
<th>ID</th>
<th>EMAIL</th>
<th>NAME</th>
<th hidden>STATUS</th>
<th>USER_TYPE</th>
<th><center>EDIT</center></th>
<th><center>STATUS</center></th>
</tr>
</thead>';
foreach($result as $row)
{
	$status = '';
	$type='';
	if($row["user_status"] == 'Active')
	{
		$status = '<label class="btn btn-success btn-sm active">Active</label>';
	}
	else
	{
		$status = '<label class="btn btn-danger btn-sm">Inactive</label>';
	}
	if($row["user_type"]=='master')
	{
		$type = '<label class="text text-primary">Master</label>';
	}
	else
	{
		$type = '<label class="text text-warning">User</label>';
	}
	$output .= '<tr>
	<td>'.$row['user_id'].'</td>
	<td>'.$row['user_email'].'</td>
	<td>'.$row['user_name'].'</td>
	<td hidden>'.$status.'</td>
	<td>'.$type.'</td>
	<td><center><button type="button" name="update" id="'.$row["user_id"].'" class="btn btn-outline btn-primary btn-sm active update"><i class="glyphicon glyphicon-edit"></i>EDIT</button></center></td>
	<td><center><label type="label" name="update" id="'.$row["user_id"].'" class="delete" data-status="'.$row["user_status"].'">
		'.$status.'</label></center></td>
	</tr>

	';
}

$output.='</tbody>
</table>';
echo($output);
?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#example').DataTable({
			responsive: true,
			"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]

		});
	});
</script>