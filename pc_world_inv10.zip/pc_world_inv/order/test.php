<?php
include('database_connection.php');
$query = "SELECT * from inventory_order_product WHERE inventory_order_id=1";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output='';
	foreach($result as $row)
	{
		$output.= $row["price"] = ["inventory_order_product_id"];
	}
	echo ($output);
?>