<?php
include('database_connection.php');
include('function.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
	<select id="category_id">
		<option>Select</option>
		<?php echo fill_category_list($connect);?>
	</select>

	<select name="brand_id" id="brand_id" class="form-control" required>
		<option value="">Select Brand</option>
	</select>

	<select id="product_id">
		<option value=""> Select Product</option>
	</select>

	<input type="text" name="amount" id="amount">

	<script type="text/javascript">
		$(document).ready(function(){
			$('#category_id').change(function(){
				var category_id = $('#category_id').val();
				var btn_action = 'load_brand';
				$.ajax({
					url:"demo_action.php",
					method:"POST",
					data:{category_id:category_id, btn_action:btn_action},
					success:function(data)
					{
						$('#brand_id').html(data);
					}
				});
			});

			$('#brand_id').change(function(){
				var brand_id = $('#brand_id').val();
				var btn_action = 'brand_data';
				$.ajax({
					url:"demo_action.php",
					method:"POST",
					data:{brand_id:brand_id, btn_action:btn_action},
					success:function(data)
					{
						$('#product_id').html(data);
					}
				});
			});

				$(document).on('click','#product_id',function(){
				var id=$(this).val();
				var btn_action='amount';
				$.ajax({
					url:"new.php",
					method:"POST",
					dataType:"json",
					data:{id:id},
					success:function(data)
					{
						//alert(data);
						$('#amount').val(data.pro_id);
					}
				})
			});
		});
	</script>
</body>
</html>