<?php
//order.php

include('header.php');

include('function.php');

// if(!isset($_SESSION['type']))
// {
// 	header('location:login.php');
// }

?>
<link rel="stylesheet" href="css/datepicker.css">
<script src="js/bootstrap-datepicker1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script>
<div class="container">
	<span id="alert_action"></span>
	<div class="row">
		<form>
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading"><label>Place Order</label></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-12">
								<input type="text" name="p_amount" id="p_amount">
								<input type="text" name="pro_id" id="pro_id">
								<input type="text" name="total" id="total">
								<input type="text" name="tax" id="tax" value="18" class="tax">
								<!---->
								<input type="hidden" name="inventory_order_id" id="inventory_order_id" />
								<input type="hidden" name="btn_action" id="btn_action" value="Add" />
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<label>Enter Receiver Name</label>
								<input type="text" name="inventory_order_name" id="inventory_order_name" class="form-control" required />
							</div>
							<div class="col-md-6">
								<label>Date</label>
								<input type="text" name="inventory_order_date" id="inventory_order_date" class="form-control" required />
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-12">
								<label>Enter Receiver Address</label>
								<textarea name="inventory_order_address" id="inventory_order_address" class="form-control" required></textarea>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-3">
								<label>Select Category</label>
								<select id="category_id" class="form-control">
									<option>Select</option>
									<?php echo fill_category_list($connect);?>
								</select>
							</div>
							<div class="col-md-3">
								<label>Select Brand</label>
								<select name="brand_id" id="brand_id" class="form-control" required>
									<option value="">Select Brand</option>
								</select>
							</div>
							<div class="col-md-3">
								<label>Select Product</label>
								<select id="product_id" class="form-control">
									<option value=""> Select Product</option>
								</select>
							</div>
							<div class="col-md-2">
								<label>Enter Quantity</label>
								<!-- <input type="text" name="qty" id="qty" class="form-control"> -->
								<select id="qty" class="form-control">
									<option value="0">--Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
							</div>
							<div class="col-md-1">
								<center><label>Add</label></center>
								<center><input type="button" name="add_btn" id="add_btn" class="btn btn-success btn-sm" value="+"></center>
							</div>
						</div>
						<hr>

						<div class="row">
							<div class="col-md-12">
								<div class="table table-responsive">
									<table id="add_tab" class="table table-bordered">
										<tr>
											<td>#</td>
											<td>Pro_ID</td>
											<td>Product</td>
											<td>Quantity</td>
											<td>amount</td>
											<td>Remove</td>
										</tr>

									</table>
									<table class="table table-bordered" id="sumt">
										<tr>
											<td style="width: 70%">Grand Total</td>
											<td style="widows: 40%" id="sub_total"><input type="text" name="grand_total" id="grand_total" style="border: none"></td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<label>Select Payment Status</label>
								<select name="payment_status" id="payment_status" class="form-control">
									<option value="cash">Cash</option>
									<option value="credit">Credit</option>
								</select>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-12">
								<center>
									<input type="button" name="action" id="action" class="btn btn-info" value="Add" />
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript" src="./order.js"></script>