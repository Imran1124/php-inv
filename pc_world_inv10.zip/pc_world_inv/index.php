<?php
//include('database_connection.php');
include('header.php');
include('function.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="container">
		<?php
		if($_SESSION['type'] == 'user')
		{
			?>
			<div class="row">
				<div class="col-md-4">
					<div class="panel panel-success">
						<div class="panel-heading">Total Category</div>
						<div class="panel-body">
							<span class="glyphicon text text-success" style="font-size:25px;"><?php echo count_total_category($connect); ?>
						</div>
					</div>
				</div>
				<!---->
				<div class="col-md-4">
					<div class="panel panel-info">
						<div class="panel-heading">Total Brand</div>
						<div class="panel-body">
							<span class="glyphicon text text-info" style="font-size:25px;"><?php echo count_total_brand($connect); ?></span>
						</div>
					</div>
				</div>
				<!---->
				<div class="col-md-4">
					<div class="panel panel-danger">
						<div class="panel-heading">Total Item in Stock</div>
						<div class="panel-body">
							<span class="glyphicon text text-danger" style="font-size:25px;"><?php echo count_total_product($connect); ?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		?>

		<?php
		if($_SESSION['type'] == 'master')
		{
			?>
			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Total User</div>
						<a href="user.php"><div class="panel-body">
							<span class="glyphicon" style="font-size:25px;"><?php echo count_total_user($connect); ?></span>
						</div></a>
					</div>
				</div>
				<!---->
				<div class="col-md-3">
					<div class="panel panel-success">
						<div class="panel-heading">Total Category</div>
						<a href="category.php"><div class="panel-body">
							<span class="glyphicon text text-success" style="font-size:25px;"><?php echo count_total_category($connect); ?></span>
						</div></a>
					</div>
				</div>
				<!---->
				<div class="col-md-3">
					<div class="panel panel-info">
						<div class="panel-heading">Total Brand</div>
						<a href="brand.php"><div class="panel-body">
							<span class="glyphicon text text-info" style="font-size:25px;"><?php echo count_total_brand($connect); ?></span>
						</div></a>
					</div>
				</div>
				<!---->
				<div class="col-md-3">
					<div class="panel panel-danger">
						<div class="panel-heading">Total Item in Stock</div>
						<a href="product.php"><div class="panel-body">
							<span class="glyphicon text text-danger" style="font-size:25px;"><?php echo count_total_product($connect); ?></span>
						</div></a>
					</div>
				</div>
			</div>
			<!---->
			<div class="row">
				<div class="col-md-4">
					<div class="panel panel-primary">
						<div class="panel-heading">Total Order Value</div>
						<div class="panel-body">
							<span class="glyphicon text text-primary" style="font-size:30px;">&#8377;<?php echo count_total_order_value($connect); ?></span>

						</div>
					</div>
				</div>
				<!---->
				<div class="col-md-4">
					<div class="panel panel-primary">
						<div class="panel-heading">Total Cash Order Value</div>
						<div class="panel-body">
							<span class="glyphicon text text-primary" style="font-size:30px;">&#8377;<?php echo count_total_cash_order_value($connect); ?></span>
						</div>
					</div>
				</div>
				<!---->
				<div class="col-md-4">
					<div class="panel panel-primary">
						<div class="panel-heading">Total Credit Order Value</div>
						<div class="panel-body">
							<span class="glyphicon text text-primary" style="font-size:30px;">&#8377;<?php echo count_total_credit_order_value($connect); ?></span>
						</div>
					</div>
				</div>
			</div>
			<!---->
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-primary">
						<div class="panel-heading"><label>Chart</label></div>
						<div class="panel-body">
							<div class="responsive">
								<div id="chart" style="height:240px;">

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		?>
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			Morris.Line({
				element : 'chart',
				data:[<?php echo chart_id($connect); ?>],
				xkey:'or_date',
				ykeys:['inven'],
				labels:['inven','or_date'],
				hideHover:'auto',
				stacked:true
			});
		});
	</script>
</body>
</html>