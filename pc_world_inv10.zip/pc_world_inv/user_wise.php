<?php
include('header.php');
include('function.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<div class="container">
	<br>
	<hr>
	<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Order Value User wise</strong></div>
				<div class="panel-body" align="center">
					<?php echo get_user_wise_total_order($connect); ?>
				</div>
			</div>
	</div>
</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
	});
</script>
</body>
</html>