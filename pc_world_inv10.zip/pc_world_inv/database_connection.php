<?php
$connect = new PDO('mysql:host=localhost;dbname=db_inventory', 'root', '');
session_start();
?>