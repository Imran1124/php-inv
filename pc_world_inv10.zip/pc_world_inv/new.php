<?php
include('database_connection.php');
include('function.php');

	$id=$_POST['id'];
	$query = "SELECT * FROM product WHERE product_id = '".$id."'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();

	//$output = '';
	foreach($result as $row)
	{
		$rmydata=available_product_quantity($connect, $row["product_id"]) . ' ' . $row["product_unit"];
		$output['qty']=$rmydata;
		$output['pro_id']=$row['product_base_price'];
		$output['pro_id']=$row['product_base_price'];
	}
	echo json_encode($output);
?>