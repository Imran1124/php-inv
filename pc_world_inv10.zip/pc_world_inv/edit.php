<?php
include('database_connection.php');
if($_POST['btn_action'] == 'fetch_single')
	{
		$query = "SELECT * FROM category WHERE category_id = :category_id";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':category_id'	=>	$_POST["category_id"]
			)
		);
		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			$output['category_name'] = $row['category_name'];
			//$output['cat_status'] = $row['category_status'];
		}
		echo json_encode($output);
	}


if($_POST['btn_action'] == "view_id")
	{
		$query = "SELECT * FROM inventory_order where inventory_order_id = :inventory_order_id";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':inventory_order_id'	=>	$_POST["viewdata"]
			)
		);

		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			$order_status='';
			$payment='';
			if($row["inventory_order_status"]=='active')
			{
				$order_status = '<label class="text text-success">Active</label>';
			}
			else
			{
				$order_status = '<label class="text text-danger">Inactive</label>';
			}
			if($row["payment_status"]=='cash')
			{
				$payment = '<label class="text text-primary">Cash</label>';
			}
			else
			{
				$payment = '<label class="text text-warning">Credit</label>';
			}
			$output['customer'] = $row['inventory_order_name'];
			$output['total_amt'] = $row['inventory_order_total'];
			$output['payment_status'] =  $payment;
			$output['order_status'] = $order_status;
			$output['order_date'] = $row['inventory_order_date'];
			$output['created'] = $_SESSION["user_name"];
		}
		echo json_encode($output);
	}

?>