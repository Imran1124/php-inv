<?php
include('header.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
include '/computer/function.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<select class="form-control">
		<option></option>
			<?php echo fill_brand_list($conn,$category_id); ?>
	</select>
</body>
</html>