<?php
include('database_connection.php');
include('function.php');

if($_POST['btn_action'] == 'load_brand')
	{
		echo fill_brand_list($connect, $_POST['category_id']);
	}

if($_POST['btn_action'] == 'brand_data')
	{
		echo fill_product_list2($connect, $_POST['brand_id']);
	}

	
?>