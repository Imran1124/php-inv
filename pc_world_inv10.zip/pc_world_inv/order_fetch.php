<?php

//order_fetch.php

include('database_connection.php');

include('function.php');

$query = '';

$output = array();

$query .= "
	SELECT * FROM inventory_order WHERE 
";

if($_SESSION['type'] == 'user')
{
	$query .= 'user_id = "'.$_SESSION["user_id"].'" AND ';
}

if(isset($_POST["search"]["value"]))
{
	$query .= '(inventory_order_id LIKE "%'.$_POST["search"]["value"].'%" ';
	$query .= 'OR inventory_order_name LIKE "%'.$_POST["search"]["value"].'%" ';
	$query .= 'OR inventory_order_total LIKE "%'.$_POST["search"]["value"].'%" ';
	$query .= 'OR inventory_order_status LIKE "%'.$_POST["search"]["value"].'%" ';
	$query .= 'OR inventory_order_date LIKE "%'.$_POST["search"]["value"].'%") ';
}

if(isset($_POST["order"]))
{
	$query .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
}
else
{
	$query .= 'ORDER BY inventory_order_id DESC ';
}

if($_POST["length"] != -1)
{
	$query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();
foreach($result as $row)
{
	$payment_status = '';

	if($row['payment_status'] == 'cash')
	{
		$payment_status = '<label class="text text-primary">Cash</label>';
	}
	else
	{
		$payment_status = '<label class="text text-warning">Credit</label>';
	}

	$status = '';
	if($row['inventory_order_status'] == 'active')
	{
		$status = '<label class="btn btn-success btn-sm active">Active</label>';
	}
	else
	{
		$status = '<span class="btn btn-danger btn-sm active">Inactive</span>';
	}
	$sub_array = array();
	$sub_array[] = $row['inventory_order_id'];
	$sub_array[] = $row['inventory_order_name'];
	$sub_array[] = $row['inventory_order_total'];
	$sub_array[] = $payment_status;
	//$sub_array[] = $status;
	$sub_array[] = $row['inventory_order_date'];
	if($_SESSION['type'] == 'master')
	{
		$sub_array[] = get_user_name($connect, $row['user_id']);
	}
	$sub_array[] = '<center><button type="button" id="'.$row["inventory_order_id"].'" class="btn btn-info btn-sm active view">View</button></center>';
	$sub_array[] = '<center><button type="button" name="update" id="'.$row["inventory_order_id"].'" class="btn btn-warning btn-sm active update">Edit</button></center>';
	$sub_array[] = '<center><label type="label" name="delete" id="'.$row["inventory_order_id"].'" class="delete" data-status="'.$row["inventory_order_status"].'">'.$status.'</label></center>';
	$data[] = $sub_array;
}

function get_total_all_records($connect)
{
	$statement = $connect->prepare("SELECT * FROM inventory_order");
	$statement->execute();
	return $statement->rowCount();
}

$output = array(
	"draw"    			=> 	intval($_POST["draw"]),
	"recordsTotal"  	=>  $filtered_rows,
	"recordsFiltered" 	=> 	get_total_all_records($connect),
	"data"    			=> 	$data
);	

echo json_encode($output);

?>