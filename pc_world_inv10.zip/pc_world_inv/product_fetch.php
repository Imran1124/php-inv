<?php

//product_fetch.php

include('database_connection.php');
include('function.php');

$query = '';

$output = array();
$query .= "
SELECT * FROM product 
INNER JOIN brand ON brand.brand_id = product.brand_id
INNER JOIN category ON category.category_id = product.category_id 
INNER JOIN user_details ON user_details.user_id = product.product_enter_by 
";

$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$output='<table class="table table-bordered table-striped table-hover" id="example">
<thead><tr>
<th>ID</th>
<th>Category</th>
<th>Brand</th>
<th>Product Name</th>
<th>Quantity</th>
<th>Enter By</th>
<th hidden>Status</th>
<th><center>View</center></th>
<th><center>Edit</center></th>
<th><center>Status</center></th>
</tr>
</thead>
<tbody>';
foreach($result as $row)
{
	$status = '';
	if($row['product_status'] == 'active')
	{
		$status = '<label class="btn btn-success btn-sm active">Active</label>';
	}
	else
	{
		$status = '<label class="btn btn-danger btn-sm active">Inactive</label>';
	}
	$output.='<tr>
	<td>'.$row['product_id'].'</td>
	<td>'.$row['category_name'].'</td>
	<td>'.$row['brand_name'].'</td>
	<td>'.$row['product_name'].'</td>
	<td>'.available_product_quantity($connect, $row["product_id"]) . ' ' . $row["product_unit"].'</td>
	<td>'.$row['user_name'].'</td>
	<td hidden>'.$status.'</td>
	<td><center><button type="button" name="view" id="'.$row["product_id"].'" class="btn btn-info btn-sm view">View</button></center></td>
	<td><center><button type="button" name="update" id="'.$row["product_id"].'" class="btn btn-warning btn-sm update">Edit</button></center></td>
	<td><center><label type="label" name="delete" id="'.$row["product_id"].'" class="delete" data-status="'.$row["product_status"].'">'.$status.'</label></center></td>
	</tr>';
}
$output.='</tbody></table>';
echo($output);
?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#example').DataTable({
			responsive: true,
			"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
			"processing":true

		});
	});
</script>