<?php
include('database_connection.php');
// if(isset($_SESSION['type']))
// {
// 	header("location:index.php");
// }

$message = '';

if(isset($_POST["log"]))
{
	$query = "
	SELECT * FROM user_details 
		WHERE user_email = :user_email
	";
	$statement = $connect->prepare($query);
	$statement->execute(
		array(
				'user_email'=>$_POST["userid"]
			)
	);
	$count = $statement->rowCount();
	if($count > 0)
	{
		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			if($row['user_status'] == 'Active')
			{
				if(password_verify($_POST["pass"], $row["user_password"]))
				{
				
					$_SESSION['type'] = $row['user_type'];
					$_SESSION['user_id'] = $row['user_id'];
					$_SESSION['user_name'] = $row['user_name'];
					header("location:index.php");
				}
				else
				{
					$message = "<label>Wrong Password</label>";
				}
			}
			else
			{
				$message = "<label>Your account is disabled, Contact Master</label>";
			}
		}
	}
	else
	{
		$message = "<label>Wrong Email Address</labe>";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>

	<div class="container-fluid">
		<div class="row">

			<div class="col-md-4">

			</div>

			<div class="col-md-4">
				<br>
				<br><br>
				<div class="card">
					<div class="card-header bg-primary text-white">
						<span>Login Here</span>
					</div>
					<div class="card-body bg-light">
						<form method="POST" action="">
							<br>
							UserId-:<input type="text" id="userid" name="userid" class="form-control" placeholder="User Id" autocomplete="off" >
							<p><span id="log" class="text-danger"></span></p>
							<br>
							Password-:<input type="Password" id="pass" name="pass" class="form-control" placeholder="Password" autocomplete="off" >
							<p><span id="pas" class="text-danger"></span></p>
							<br>
							<input type="submit" id="but" name="log" value="Login" class="btn btn-primary" onclick="return show()">
							<br>
							<br>
							<a href="#"><span class="text text-primary">Forgot</span></a>|
							<a href="SingIn.php"><span class="text text-primary">SingIn</span></a>
							<br>
							<br>
							<br>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-4">
			</div>
		</div>
	</div>
	<script type="text/javascript">
		function show()
		{
			var uid=document.getElementById('userid').value;
			var pass=document.getElementById('pass').value;

			if(uid=="")
			{
				document.getElementById('log').innerHTML="* Please fill the userid!";
				document.getElementById('userid').focus();
				return false;
			}
			if(pass=="")
			{
				document.getElementById('pas').innerHTML="* Please fill the password!";
				document.getElementById('pass').focus();
				return false;
			}
		};
	</script>
</body>
</html>