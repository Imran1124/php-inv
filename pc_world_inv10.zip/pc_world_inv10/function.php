<?php

function savedata($connect,$tab,$arrayName)
{
	foreach ($arrayName as $key => $value)
	{
		$k[]=$key;
		$v[]="'".$value."'";

	}
	$val="'".$value."'";
	$query="SELECT * FROM ".$tab." where ".$key."=".$val." ";
	$statement=$connect->prepare($query);
	$statement->execute();
	$result=$statement->rowCount();
	if($result>0)
	{
		echo "already Exits";
	}
	else
	{
		$k=implode(",",$k);
		$v=implode(",",$v);
		
		$query="INSERT INTO ".$tab." ($k)VALUES($v)";
		$statement = $connect->prepare($query);
		$statement->execute();
		if($statement)
		{
			echo "inserted";
		}
		else
		{
			echo "Fails data";
		}
	}
	return $connect;
}

function update($connect,$tab,$arrayName)
{
	foreach ($arrayName as $key => $value)
	{
		$k[]="".$key."".'='.$v[]="'".$value."'";
	}
	$k=implode(',',$k);
	$query="UPDATE  ".$tab." SET $k where ".$key."=".$value." ";
	$statement = $connect->prepare($query);
	$statement->execute();
	if($statement)
	{
		echo "updated";
	}
	else
	{
		echo "Fails data";
	}
	return $connect;
}

function fill_category_list($connect)
{
	$query = "SELECT * FROM category WHERE category_status = 'Active' GROUP BY category_name ORDER BY category_name ASC";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["category_id"].'">'.$row["category_name"].'</option>';
	}
	return $output;
}

function fill_brand_list($connect, $category_id)
{
	$query = "SELECT * FROM brand WHERE brand_status = 'active' AND category_id = '".$category_id."'ORDER BY brand_name ASC";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '<option value="">Select Brand</option>';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["brand_id"].'">'.$row["brand_name"].'</option>';
	}
	return $output;
}

function fill_product_list2($connect,$brand_id)
{
	$query = "SELECT * FROM product WHERE product_status = 'active' AND brand_id = '".$brand_id."' ORDER BY product_name ASC";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '<option value="">Select Product</option>';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["product_id"].'">'.$row["product_name"].'</option>';
	}
	return $output;
}

function get_user_name($connect, $user_id)
{
	$query = "SELECT user_name FROM user_details WHERE user_id = '".$user_id."'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return $row['user_name'];
	}
}

function fill_product_list($connect)
{
	$query = "SELECT * FROM product WHERE product_status = 'active' ORDER BY product_name ASC";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["product_id"].'">'.$row["product_name"].'</option>';
	}
	return $output;
}

function fetch_product_details($product_id, $connect)
{
	$query = "SELECT * FROM product WHERE product_id = '".$product_id."'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output['product_name'] = $row["product_name"];
		$output['quantity'] = $row["product_quantity"];
		$output['price'] = $row['product_base_price'];
		$output['tax'] = $row['product_tax'];
	}
	return $output;
}

function available_product_quantity($connect, $product_id)
{
	$vbl='qty';
	$product_data = fetch_product_details($product_id, $connect);
	$query="call view_pro_detail('".$vbl."','".$product_id."')";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total = 0;
	foreach($result as $row)
	{
		$total = $total + $row['quantity'];
	}
	$available_quantity = intval($product_data['quantity']) - intval($total);

	// $query_qty="update product set product_quantity = :available_quantity WHERE product_id=:pro_id ";
	// $statement = $connect->prepare($query_qty);
	// $statement->execute(array(":available_quantity"=> $available_quantity, ":product_id"=> $product_id));
	// $result = $statement->fetchAll();
	if($available_quantity == 0)
	{
		$update_query = "
		UPDATE product SET 
		product_status = 'inactive' 
		WHERE product_id = '".$product_id."'
		";
		$statement = $connect->prepare($update_query);
		$statement->execute();
	}
	return $available_quantity;
}

function count_total_user($connect)
{
	$query = "
	SELECT * FROM user_details WHERE user_status='active'";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

function count_total_category($connect)
{
	$query = "
	SELECT * FROM category WHERE category_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

function count_total_brand($connect)
{
	$query = "
	SELECT * FROM brand WHERE brand_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

function count_total_product($connect)
{
	$query = "
	SELECT * FROM product WHERE product_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

function count_total_order_value($connect)
{
	$vbl='total_order_value';
	$query = "call count_total('".$vbl."')";
	
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}

function count_total_cash_order_value($connect)
{
	$vbl='total_cash_order';
	$query = "call count_total('".$vbl."')";
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}

function count_total_credit_order_value($connect)
{
	$vbl='total_credit';
	$query = "call count_total('".$vbl."')";
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}

function get_user_wise_total_order($connect)
{
	$vbl= 'user_wise_total_order';
	$query = "call fetch_order_list('".$vbl."')";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '
	<div class="table-responsive">
		<table class="table table-bordered table-striped">
			<tr>
				<th>User Name</th>
				<th>Total Order Value</th>
				<th>Total Cash Order</th>
				<th>Total Credit Order</th>
			</tr>
	';

	$total_order = 0;
	$total_cash_order = 0;
	$total_credit_order = 0;
	foreach($result as $row)
	{
		$output .= '
		<tr>
			<td>'.$row['user_name'].'</td>
			<td align="right">&#8377; '.$row["order_total"].'</td>
			<td align="right">&#8377; '.$row["cash_order_total"].'</td>
			<td align="right">&#8377; '.$row["credit_order_total"].'</td>
		</tr>
		';

		$total_order = $total_order + $row["order_total"];
		$total_cash_order = $total_cash_order + $row["cash_order_total"];
		$total_credit_order = $total_credit_order + $row["credit_order_total"];
	}
	$output .= '
	<tr>
		<td align="right"><b>Total</b></td>
		<td align="right"><b>&#8377; '.$total_order.'</b></td>
		<td align="right"><b>&#8377; '.$total_cash_order.'</b></td>
		<td align="right"><b>&#8377; '.$total_credit_order.'</b></td>
	</tr></table></div>
	';
	return $output;
}

function chart_id($connect)
{
	$query = "SELECT SUM(inventory_order_total)as inven,inventory_order_date AS or_date FROM `inventory_order` WHERE inventory_order_date GROUP BY inventory_order_date" ;
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$chart_data = '';
	foreach ($result as $row) 
	{
		$chart_data .= "{ or_date:'".$row["or_date"]."', inven:".$row["inven"]."}, ";
	}
	$chart_data = substr($chart_data, 0, -2);
	return $chart_data;
}
?>