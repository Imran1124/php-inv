	<?php

//category_action.php

	include('database_connection.php');
	include('function.php');
	if(isset($_POST['btn_action']))
	{
		if($_POST['btn_action'] == 'Add')
		{
			$c_name=$_POST["c_name"];
			$cat_status=$_POST['cat_status'];
			$vbl='insrt';
			$active="active";
			for($i=0;$i<count($c_name);$i++)
			{
				savedata($connect,$tab="category",$arrayName = array("category_name"=>$c_name[$i],"category_status"=>$cat_status[$i]));
			}
			
		}

		if($_POST['btn_action'] == 'fetch_single')
		{
			$query = "SELECT * FROM category WHERE category_id = :category_id";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					':category_id'	=>	$_POST["category_id"]
				)
			);
			$result = $statement->fetchAll();
			foreach($result as $row)
			{
				$output['category_name'] = $row['category_name'];
				$output['cat_status'] = $row['category_status'];
			}
			echo json_encode($output);
		}

		if($_POST['btn_action'] == 'Edit')
		{
			$cat_id=$_POST["cat_id"];
			$cat_name=$_POST["c_name"];
			$cat_status=$_POST['cat_status'];
			$vbl1='upd';
			for($i=0;$i<count($cat_id);$i++)
			{
				update($connect,$tab="category",$arrayName = array("category_name"=>$cat_name[$i],"category_status"=>$cat_status[$i],"category_id"=>$cat_id[$i]));
			}
		}
		if($_POST['btn_action'] == 'delete')
		{
			$vbl='change_status';
			$status = 'active';
			if($_POST['status'] == 'active')
			{
				$status = 'inactive';	
			}
			$query = "call active_inactive_cat_brand_product('".$vbl."',:cat_id,:status_ch)";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					':cat_id'		=>	$_POST["category_id"],
					':status_ch'	=>	$status
				)
			);
			$result = $statement->fetchAll();
			if(isset($result))
			{
				echo 'Succcessfully Category status change to ' . $status;
			}
		}


		if($_POST['btn_action']=='exist')
		{
			$query="SELECT * FROM category WHERE category_name=:cat_name";
			$statement=$connect->prepare($query);
			$statement->execute(array(":cat_name"=>$_POST['category_name']));
			$result=$statement->rowCount();
			if($result>0)
			{
				echo "<span class='text text-danger'>Category Name Already Exist!</span>";
			}
			else
			{
				echo "<span class='text text-success'>Category Name Not Exist</span>";
			}
		}
	}

	
	

	?>