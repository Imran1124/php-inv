<?php
//category.php

include('header.php');

if(!isset($_SESSION['type']))
{
	header('location:login.php');
}

if($_SESSION['type'] != 'master')
{
	header("location:index.php");
}
?>
<div class="container">
	<span id="alert_action"></span>
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="col-lg-10 col-md-10 col-sm-8 col-xs-6">
						<div class="row">
							<label class="panel-title">Category List</label>
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
						<div class="row" align="right">
							<button type="button" name="add" id="add_button" data-toggle="modal" data-target="#categoryModal" class="btn btn-success btn-sm active">Add Category</button>   		
						</div>
					</div>
					<div style="clear:both"></div>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-sm-12 table-responsive">
							<div class="table table-responsive" id="view_record">
								<!--View RECORD-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="categoryModal" class="modal fade">
		<div class="modal-dialog">
			<form method="post" id="category_form">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><i class="fa fa-plus"></i> Add Category</h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-6">
								<label>Enter Category Name</label>
								<input type="text" name="category_name" id="category_name" class="form-control" required />
								<span id="exist_category"></span>
							</div>
							<div class="col-md-6">
								<label>Select Category Status</label>
								<select class="form-control" id="cat_status">
									<option>active</option>
									<option>inactive</option>
								</select>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-12">
								<div class="table table-responsive">
									<table class="table table-bordered" id="add_tab">
										<tr>
											<td>#</td>
											<td hidden>C_ID</td>
											<td>Categorie</td>
											<td>CatStatus</td>
											<td>Remove</td>
										</tr>
									</table>
									<center><input type="button" name="add" id="add" class="btn btn-info btn-sm" value="Add" /></center>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<input type="text" name="category_id" id="category_id"/>
						<input type="text" name="btn_action" id="btn_action" value="Add" />
						<input type="button" name="save" id="save" class="btn btn-primary btn-sm active" value="SUBMIT" data-dismiss="modal"/>
						<button type="button" class="btn btn-default btn-sm active" data-dismiss="modal">Close</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<script type="text/javascript" src="./myquery/category.js"></script>
<script type="text/javascript">
	// $(document).ready(function(){
		
	// })
</script>


