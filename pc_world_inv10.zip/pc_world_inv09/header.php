<?php include('database_connection.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>PC-WORLD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <!-- DataTable 3 -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap.min.css">
  <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap.min.js"></script>
  <!-- DataTable 3 -->

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script> -->
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
  <link rel="stylesheet" type="text/css" href="./stylecss/style.css">
</head>
<body>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
        </button>
        <a class="navbar-brand active" href="index"><span class="text text-primary active">PC-WORLD</span></a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <?php
          if($_SESSION['type'] == 'master')
          {
          ?>
          <li><a href="user"><span class="glyphicon glyphicon-user"></span>user</a></li>
          <li><a href="category"><span class="glyphicon glyphicon-list"></span>Category</a></li>
          <li><a href="brand">Brand</a></li>
          <li><a href="product">Product</a></li>
          <?php
          }
          ?>
          <li><a href="order_main">Order</a></li>
          <?php
          if($_SESSION['type'] == 'master')
          {
          ?>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">More<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="user_wise">User Detail</a></li>
              <li><a href="order.php">View Order List</a></li>
            </ul>
          </li>
          <?php
          }
          ?>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="#"><span class="glyphicon glyphicon-user"></span><?php echo $_SESSION["user_name"]; ?> </a></li>
          <li><a href="logout"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

<style>
    #overlay{ 
  position: fixed;
  top: 0;
  z-index: 100%;
  width: 100%;
  height:100%;
  display: none;
  background: rgba(0,0,0,0.4);
}
.cv-spinner {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;  
}
.spinner {
  width: 100px;
  height: 100px;
  border: 8px #ddd solid;
  border-top: 8px #2e93e6 solid;
  border-radius: 50%;
  animation: sp-anime 0.6s infinite linear;
}
@keyframes sp-anime {
  100% { 
    transform: rotate(360deg); 
  }
}
.is-hide{
  display:none;
}
  </style>

<div id="overlay">
    <div class="cv-spinner">
      <span class="spinner"></span>
    </div>
  </div>




  <script type="text/javascript">
    $(document).ready(function(){
      $('.container').addClass('container-loaded');
    });
  </script>
