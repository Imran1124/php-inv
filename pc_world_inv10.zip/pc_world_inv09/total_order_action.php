
<?php
include('database_connection.php');

include('function.php');

if(isset($_POST["view"]))
{
	$f_date=$_POST['view'];
	$t_date=$_POST['view'];
	$query="SELECT * from inventory_order  WHERE inventory_order_date BETWEEN '".$f_date."' AND '".$t_date."' ";
}
else
{
	$query="SELECT * from inventory_order order by inventory_order_id";
}
$statement = $connect->prepare($query);
$statement->execute();
$data=$statement->fetchAll();
$result=$statement->rowCount();
//$output='';
if($result>0)
{
	$output='
	<table class="table table-responsive">
	<thead>
	<th>OrderID</th>
	<th>Customer Name</th>
	<th>Total Amount</th>
	<th>Payment Status</th>
	<th>Order Date</th>
	</thead>
	<tbody>
	';

	foreach ($data as $row) 
	{
		$payment_status = '';

		if($row['payment_status'] == 'cash')
		{
			$payment_status = '<label class="text text-primary">Cash</label>';
		}
		else
		{
			$payment_status = '<label class="text text-warning">Credit</label>';
		}

		$status = '';
		if($row['inventory_order_status'] == 'active')
		{
			$status = '<label class="btn btn-success btn-sm active">Active</label>';
		}
		else
		{
			$status = '<span class="btn btn-danger btn-sm active">Inactive</span>';
		}
		$output.='
		<tr>
		<td>'.$row["inventory_order_id"].'</td>
		<td>'.$row['inventory_order_name'].'</td>
		<td>'.$row['inventory_order_total'].'</td>
		<td>'.$payment_status.'</td>
		<td>'.$row['inventory_order_date'].'</td>
		</tr>
		';
	}
	$output.='</tbody></table>';

	echo ($output);
}
else
{
	echo "No Record Found";
}
?>