$(document).ready(function(){
	load_data();
	$('#save').attr('disabled','disabled');
	$('#save').attr('disabled','true');
	$('#add_button').click(function(){
		$('#brandModal').modal('show');
		$('#brand_form')[0].reset();
		$('.modal-title').html("<i class='fa fa-plus'></i> Add Brand");
		$('#action').val('Add');
		$('#btn_action').val('Add');
	});

	//add record
		var i=1;
		$('#add').click(function(){
			$('#save').removeAttr('disabled');
			var item=i++;
			var brand_id=$('#brand_id').val();
			var brand_name=$('#brand_name').val();
			var cat_val=$('#category_id').val();
			var cat_id1=$('#category_id option:selected').text();

			if(cat_val==''||brand_name=='')
			{
				alert('All Field Required');
				return false;
			}

			$('#add_tab').append('<tr class="rmv_tab" id="'+item+'">'+
				'<td>'+item+'</td>'+
				'<td id="brand_id" class="brand_id '+item+'">'+brand_id+'</td>'+
				'<td hidden id="cat_val" class="cat_val '+item+'">'+cat_val+'</td>'+
				'<td id="cat_id" class="cat_id '+item+'">'+cat_id1+'</td>'+
				'<td id="brand_name" class="brand_name '+item+'">'+brand_name+'</td>'+
				'<td ><a href="javascript:void(0)" class="remCF">Remove</a></td>'+
				'</tr>');
		});
		$("#add_tab").on('click', '.remCF', function() {
			$(this).parent().parent().remove();
		});

		$(document).on('click','.remCF',function(){
				var rmv=$('.rmv_tab').length;
				if(rmv==0)
				{
					$('#save').attr('disabled','disabled');
				}
			});

		$('#save').click(function(){
			var btn_action=$('#btn_action').val();
			var brand_id=[];
			var cat_val=[];
			var brand_name=[];

			$('.brand_id').each(function(){
				brand_id.push($(this).text());
			});
			$('.cat_val').each(function(){
				cat_val.push($(this).text());
			});
			$('.brand_name').each(function(){
				brand_name.push($(this).text());
			});
			$.ajax({
				url:"brand_action.php",
				type:"POST",
				data:{btn_action:btn_action,brand_id:brand_id,cat_val:cat_val,brand_name:brand_name},
				beforeSend:function()
				{
					$('#overlay').css("display", "block");
				},
				success:function(data)
				{
					$('#overlay').css("display", "none");
					$('#brand_form')[0].reset();
					$('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
					//alert(data);
					$('.rmv_tab').remove();
					$('#save').val('SUBMIT');
					$('#save').attr('disabled','disabled');
					load_data();
					$('.container').addClass('container-loaded');
				}
			});
		});

	$(document).on('click', '.update', function(){
		var brand_id = $(this).attr("id");
		var btn_action = 'fetch_single';
		$.ajax({
			url:'brand_action.php',
			method:"POST",
			data:{brand_id:brand_id, btn_action:btn_action},
			dataType:"json",
			beforeSend:function()
			{
				$('#overlay').css("display", "block");
			},
			success:function(data)
			{
				$('#overlay').css("display", "none");
				$('#brandModal').modal('show');
				$('#category_id').val(data.category_id);
				$('#brand_name').val(data.brand_name);
				$('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Brand");
				$('#brand_id').val(brand_id);
				$('#action').val('Edit');
				$('#btn_action').val('Edit');
				$('#save').val('Update');
			}
		})
	});

	$(document).on('click','.delete', function(){
		var brand_id = $(this).attr("id");
		var status  = $(this).data('status');
		var btn_action = 'delete';
		if(confirm("Are you sure you want to change status?"))
		{
			$.ajax({
				url:"brand_action.php",
				method:"POST",
				data:{brand_id:brand_id, status:status, btn_action:btn_action},
				success:function(data)
				{
					$('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
					// branddataTable.ajax.reload();
					load_data();
				}
			})
		}
		else
		{
			return false;
		}
	});

});

function load_data(view)
{
	$.ajax({

		url:"brand_fetch.php",
		type:"POST",
		data:{view:view},
		success:function(data)
		{
			$('#show_data').html(data);
		}
	});
}