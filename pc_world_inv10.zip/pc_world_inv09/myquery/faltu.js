$(document).ready(function(){

for (var i = 0; i < Things.length; i++)
{
	Things[i]
}

});