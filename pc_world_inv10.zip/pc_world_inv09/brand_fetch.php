<?php
include('database_connection.php');
$query="SELECT * FROM brand INNER JOIN category ON category.category_id = brand.category_id ";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
	$output='<table class="table table-bordered table-striped table-hover" id="example">

<thead>
<tr>
<th>ID</th>
<th>CATEGORY NAME</th>
<th>BRAND NAME</th>
<th hidden>STATUS</th>
<th>EDIT</th>
<th>DELETE</th>
</tr>
</thead>';
foreach($result as $row)
{
	$status = '';
	if($row["brand_status"] == 'active')
	{
		$status = '<label class="btn btn-success btn-sm active">Active</label>';
	}
	else
	{
		$status = '<label class="btn btn-danger btn-sm active">Inactive</label>';
	}
	$output .= '<tr>
	<td>'.$row['brand_id'].'</td>
	<td>'.$row['category_name'].'</td>
	<td>'.$row['brand_name'].'</td>
	<td hidden>'.$status.'</td>
	<td><center><button type="button" name="update" id="'.$row["brand_id"].'" class="btn btn-outline btn-primary btn-sm active update"><i class="glyphicon glyphicon-edit"></i>EDIT</button></center></td>
	<td><center><label type="label" name="update" id="'.$row["brand_id"].'" class="delete" data-status="'.$row["brand_status"].'">'.$status.'</label></center></td>
	</tr>';
}

$output.='</tbody>
</table>';
echo($output);
?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#example').DataTable({
			responsive: true,
			"lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]

		});
	});
</script>