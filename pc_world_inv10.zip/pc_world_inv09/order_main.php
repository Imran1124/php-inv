<?php
//order.php

include('header.php');

include('function.php');

if(!isset($_SESSION['type']))
{
	header('location:login.php');
}

?>
<!-- <div id="overlay">
	<div class="cv-spinner">
		<span class="spinner"></span>
	</div>
</div> -->
<!-- model -->
<div class="container">
	<div class="row">
		<form id="order_form" action="invoice.php" method="POST" target="_blank">
			<!-- model -->
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">PRINT INVOICE</h4>
						</div>
						<div class="modal-body">
							<span id="alert_action"></span>
							<input type="hidden" name="invoice" id="invoice">
						</div>
						<div class="modal-footer">
							<button type="submit" name="save_invoice" class="btn btn-success active" data-dismiss="model">Print</button>
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>

				</div>
			</div>
			<!-- close model -->
			
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading"><label>Place Order</label></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-12">
								<input type="hidden" name="p_amount" id="p_amount">
								<input type="hidden" name="pro_id" id="pro_id">
								<input type="hidden" name="total" id="total">
								<input type="hidden" name="tax" id="tax" value="18" class="tax">
								<!---->
								<input type="hidden" name="inventory_order_id" id="inventory_order_id" />
								<input type="hidden" name="btn_action" id="btn_action" value="Add" />
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<label>Enter Receiver Name</label>
								<input type="text" name="inventory_order_name" id="inventory_order_name" class="form-control" />
							</div>
							<div class="col-md-4">
								<label>Phone No</label>
								<input type="text" name="inventory_order_mobile" id="inventory_order_mobile" class="form-control" />
							</div>
							<div class="col-md-4">
								<label>Date</label>
								<input type="text" name="inventory_order_date" id="inventory_order_date" class="form-control" 
								placeholder="yyyy-mm-dd" />
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-12">
								<label>Enter Receiver Address</label>
								<textarea name="inventory_order_address" id="inventory_order_address" class="form-control" ></textarea>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-3">
								<label>Select Category</label>
								<select id="category_id" class="form-control">
									<option>Select</option>
									<?php echo fill_category_list($connect);?>
								</select>
							</div>
							<div class="col-md-3">
								<label>Select Brand</label>
								<select name="brand_id" id="brand_id" class="form-control" >
									<option value="">Select Brand</option>
								</select>
							</div>
							<div class="col-md-3">
								<label>Select Product</label>
								<select id="product_id" class="form-control">
									<option value=""> Select Product</option>
								</select>
							</div>
							<div class="col-md-2">
								<label>Enter Quantity</label>
								<!-- <input type="text" name="qty" id="qty" class="form-control"> -->
								<select id="qty" class="form-control">
									<option value="0">--Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
							</div>
							<div class="col-md-1">
								<center><label>Add</label></center>
								<center><input type="button" name="add_btn" id="add_btn" class="btn btn-success btn-sm" value="+"></center>
							</div>
						</div>
						<hr>

						<div class="row">
							<div class="col-md-12">
								<div class="table table-responsive">
									<table id="add_tab" class="table table-bordered">
										<tr>
											<td>#</td>
											<td>Pro_ID</td>
											<td>Product</td>
											<td>Quantity</td>
											<td>amount</td>
											<td>Remove</td>
										</tr>

									</table>
									<table class="table table-bordered" id="sumt">
										<tr>
											<td>Total Amount</td>
											<td>Tax Amount</td>
											<td>Grand Total</td>
										</tr>
										<tr>
											<td style="widows: 25%" id="sub_total"><input type="text" name="total_amount" id="total_amount" style="border: none"></td>
											<td style="widows: 25%" id="sub_total"><input type="text" name="tax_amount" id="tax_amount" style="border: none"></td>
											<td style="widows: 25%" id="sub_total"><input type="text" name="grand_total" id="grand_total" style="border: none"></td>
										</tr>
									</table>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<label>Select Payment Status</label>
								<select name="payment_status" id="payment_status" class="form-control">
									<option value="cash">Cash</option>
									<option value="credit">Credit</option>
								</select>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-12">
								<center>
									<input type="button" name="action" id="action" class="btn btn-info" value="SUBMIT" />
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript" src="myquery/order.js"></script>
