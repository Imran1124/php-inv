<?php

//order_action.php

include('database_connection.php');

include('function.php');

if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'Add')
	{
		$vbl='insrt';
		$query = "call inventory_order_proc('".$vbl."','".null."',:user_id,:inventory_total,:inventory_tax, :inventory_order_total, :inventory_order_date, :inventory_order_name, :inventory_order_mobile, :inventory_order_address, :payment_status, :inventory_order_status, :inventory_order_created_date)";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':user_id'						=>	$_SESSION["user_id"],
				':inventory_total'				=>	$_POST["total_amount"],
				':inventory_tax'				=> 	$_POST["tax_amount"],
				':inventory_order_total'		=>	$_POST['grand_total'],
				':inventory_order_date'			=>	$_POST['inventory_order_date'],
				':inventory_order_name'			=>	$_POST['inventory_order_name'],
				':inventory_order_mobile'		=>	$_POST['inventory_order_mobile'],
				':inventory_order_address'		=>	$_POST['inventory_order_address'],
				':payment_status'				=>	$_POST['payment_status'],
				':inventory_order_status'		=>	'active',
				':inventory_order_created_date'	=>	$_POST['inventory_order_date']
			)
		);
		$result = $statement->fetchAll();
		$statement = $connect->query("SELECT LAST_INSERT_ID()");
		$inventory_order_id = $statement->fetchColumn();

		if(isset($inventory_order_id))
		{
			//$total_amount = 0;
			for($count = 0; $count<count($_POST["pro_id"]); $count++)
			{
				//$product_details = fetch_product_details($_POST["product_id"][$count], $connect);
				$sub_query = "
				INSERT INTO inventory_order_product (inventory_order_id, product_id, quantity, price, tax) VALUES (:inventory_order_id, :product_id, :quantity, :price, :tax)
				";
				$statement = $connect->prepare($sub_query);
				$statement->execute(
					array(
						':inventory_order_id'	=>	$inventory_order_id,
						':product_id'			=>	$_POST["pro_id"][$count],
						':quantity'				=>	$_POST["qty"][$count],
						':price'				=>	$_POST["total"][$count],
						':tax'					=>	'18'
					)
				);
			}
			$result = $statement->fetchAll();
			if(isset($result))
			{
				echo $inventory_order_id;
			}
		}
	}

	if($_POST['btn_action'] == 'fetch_single')
	{
		$query = "
		SELECT * FROM inventory_order WHERE inventory_order_id = :inventory_order_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':inventory_order_id'	=>	$_POST["inventory_order_id"]
			)
		);
		$result = $statement->fetchAll();
		$output = array();
		foreach($result as $row)
		{
			$output['inventory_order_name'] = $row['inventory_order_name'];
			$output['inventory_order_date'] = $row['inventory_order_date'];
			$output['inventory_order_address'] = $row['inventory_order_address'];
			$output['payment_status'] = $row['payment_status'];
		}
		echo json_encode($output);
	}

	if($_POST['btn_action'] == 'Edit')
	{
		$delete_query = "
		DELETE FROM inventory_order_product 
		WHERE inventory_order_id = '".$_POST["inventory_order_id"]."'
		";
		$statement = $connect->prepare($delete_query);
		$statement->execute();
		$delete_result = $statement->fetchAll();
		if(isset($delete_result))
		{
			$total_amount = 0;
			for($count = 0; $count < count($_POST["product_id"]); $count++)
			{
				$product_details = fetch_product_details($_POST["product_id"][$count], $connect);
				$sub_query = "
				INSERT INTO inventory_order_product (inventory_order_id, product_id, quantity, price, tax) VALUES (:inventory_order_id, :product_id, :quantity, :price, :tax)
				";
				$statement = $connect->prepare($sub_query);
				$statement->execute(
					array(
						':inventory_order_id'	=>	$_POST["inventory_order_id"],
						':product_id'			=>	$_POST["product_id"][$count],
						':quantity'				=>	$_POST["quantity"][$count],
						':price'				=>	$product_details['price'],
						':tax'					=>	$product_details['tax']
					)
				);
				$base_price = $product_details['price'] * $_POST["quantity"][$count];
				$tax = ($base_price/100)*$product_details['tax'];
				$total_amount = $total_amount + ($base_price + $tax);
			}
			$update_query = "
			UPDATE inventory_order 
			SET inventory_order_name = :inventory_order_name, 
			inventory_order_date = :inventory_order_date, 
			inventory_order_address = :inventory_order_address, 
			inventory_order_total = :inventory_order_total, 
			payment_status = :payment_status
			WHERE inventory_order_id = :inventory_order_id
			";
			$statement = $connect->prepare($update_query);
			$statement->execute(
				array(
					':inventory_order_name'			=>	$_POST["inventory_order_name"],
					':inventory_order_date'			=>	$_POST["inventory_order_date"],
					':inventory_order_address'		=>	$_POST["inventory_order_address"],
					':inventory_order_total'		=>	$total_amount,
					':payment_status'				=>	$_POST["payment_status"],
					':inventory_order_id'			=>	$_POST["inventory_order_id"]
				)
			);
			$result = $statement->fetchAll();
			if(isset($result))
			{
				echo 'Successfully Order Edited...';
			}
		}
	}

	if($_POST['btn_action'] == 'delete')
	{
		$status = 'active';
		if($_POST['status'] == 'active')
		{
			$status = 'inactive';
		}
		$query = "
		UPDATE inventory_order 
		SET inventory_order_status = :inventory_order_status 
		WHERE inventory_order_id = :inventory_order_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':inventory_order_status'	=>	$status,
				':inventory_order_id'		=>	$_POST["inventory_order_id"]
			)
		);
		$result = $statement->fetchAll();
		if(isset($result))
		{
			echo 'Successfully status change to ' . $status;
		}
	}

	if($_POST['btn_action'] == 'view_id')
	{
		$query = "call join_product_orderproduct_order('".$vbl='fetch_all_data'."',:order_id)";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':order_id'	=>	$_POST["viewdata"]
			)
		);

		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			$order_status='';
			$payment='';
			if($row["inventory_order_status"]=='active')
			{
				$order_status = '<label class="text text-success">Active</label>';
			}
			else
			{
				$order_status = '<label class="text text-danger">Inactive</label>';
			}
			if($row["payment_status"]=='cash')
			{
				$payment = '<label class="text text-primary">Cash</label>';
			}
			else
			{
				$payment = '<label class="text text-warning">Credit</label>';
			}
			$output['customer'] = $row['inventory_order_name'];
			$output['total_amt'] = $row['inventory_order_total'];
			$output['payment_status'] =  $payment;
			$output['order_status'] = $order_status;
			$output['order_date'] = $row['inventory_order_date'];
			$output['created'] = $_SESSION["user_name"];
			$output['product_n'] = $row['product_name'];
			$output['brand_n'] = $row['brand_name'];
			$output['qty1'] = $row['quantity'];
		}
		echo json_encode($output);
	}

	//load drop down list
	if($_POST['btn_action'] == 'load_brand')
	{
		echo fill_brand_list($connect, $_POST['category_id']);
	}

	if($_POST['btn_action'] == 'brand_data')
	{
		echo fill_product_list2($connect, $_POST['brand_id']);
	}

	if($_POST['btn_action']=='amount')
	{
		$id=$_POST['id'];
		$query = "SELECT * FROM product WHERE product_id = '".$id."'";
		$statement = $connect->prepare($query);
		$statement->execute();
		$result = $statement->fetchAll();

		foreach($result as $row)
		{
			$rmydata=available_product_quantity($connect, $row["product_id"]) . ' ' . $row["product_unit"];
			$output['qty']=$rmydata;
			$output['pro_id']=$row['product_base_price'];
			$output['pro_id']=$row['product_base_price'];
		}
		echo json_encode($output);
	}
}

?>