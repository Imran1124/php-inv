<?php

//brand_action.php

include('database_connection.php');
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'Add')
	{
		$cat_val=$_POST['cat_val'];
		$b_name=$_POST['brand_name'];
		$vbl='insrt';
		for ($i=0; $i <count($cat_val) ; $i++) 
		{ 
			$query="SELECT * from brand WHERE brand_name=:brand_name and category_id=:cat_val";
			$statement=$connect->prepare($query);
			$statement->execute(array(":brand_name"=>$b_name[$i], ":cat_val"=>$cat_val[$i]));
			$result=$statement->rowCount();
		}
		if($result>0)
		{
			echo "Already Exists";
		}
		else
		{
			for($i=0; $i<count($cat_val);$i++)
			{
				$query = "call pro_brand('".$vbl."','".null."',:cat_val,:b_name)";
				$statement = $connect->prepare($query);
				$statement->execute(
					array(
						':cat_val'	=>	$cat_val[$i],
						':b_name'	=>	$b_name[$i]
					)
				);
				$result = $statement->fetchAll();
			}
			if(isset($result))
			{
				echo 'Successfully Brand Name Added';
			}
		}
	}

	if($_POST['btn_action'] == 'fetch_single')
	{
		$query = "
		SELECT * FROM brand WHERE brand_id = :brand_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':brand_id'	=>	$_POST["brand_id"]
			)
		);
		$result = $statement->fetchAll();
		foreach($result as $row)
		{
			$output['category_id'] = $row['category_id'];
			$output['brand_name'] = $row['brand_name'];
		}
		echo json_encode($output);
	}
	if($_POST['btn_action'] == 'Edit')
	{
		$b_id=$_POST["brand_id"];
		$cat_val=$_POST['cat_val'];
		$b_name=$_POST['brand_name'];
		$vbl='upd';
		for($i=0; $i<count($cat_val);$i++)
		{
			$query = "call pro_brand('".$vbl."',:b_id,:cat_val,:b_name)";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					':b_id'=>$b_id[$i],
					':cat_val'	=>	$cat_val[$i],
					':b_name'	=>	$b_name[$i]
				)
			);
			$result = $statement->fetchAll();
		}
		if(isset($result))
		{
			echo 'Successfully Brand Name Updated';
		}
	}

	if($_POST['btn_action'] == 'delete')
	{
		$status = 'active';
		if($_POST['status'] == 'active')
		{
			$status = 'inactive';
		}
		$query = "UPDATE brand SET brand_status = :brand_status WHERE brand_id = :brand_id";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':brand_status'	=>	$status,
				':brand_id'		=>	$_POST["brand_id"]
			)
		);
		$result = $statement->fetchAll();
		if(isset($result))
		{
			echo 'Successfully Brand status change to ' . $status;
		}
	}
}

?>