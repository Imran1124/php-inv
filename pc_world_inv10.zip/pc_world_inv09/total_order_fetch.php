<?php
//order.php

include('header.php');

include('function.php');

if(!isset($_SESSION['type']))
{
	header('location:login.php');
}

?>
<div class="container">
	<span id="alert_action"></span>
	<div class="row">
		<div class="col-md-4">From-: <input type="text" name="f_date" id="f_date" class="form-control"></div>
		<div class="col-md-4">To-: <input type="text" name="to_date" id="to_date" class="form-control"></div>
		<div class="col-md-4"><br><input type="button" name="serch" id="serch" value="Serch" class="btn btn-info btn-sm active"></div>
	</div>
	<hr>
	<div class="row">
		<div class="col-lg-12">

			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="row">
						<div class="col-lg-10 col-md-10 col-sm-8 col-xs-6">
							<label>Order</label>
						</div>
						<div class="col-lg-2 col-md-2 col-sm-4 col-xs-6" align="right">
							<button type="button" name="add" id="print_by" class="btn btn-success btn-sm active">Print By Order-ID</button>    	
						</div>
					</div>
				</div>
				<div class="panel-body">
					<div class="table table-responsive" id="fetch_data">

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- model -->
<form id="order_form" action="invoice.php" method="POST" target="_blank">
	<div class="modal fade" id="myModal" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Print By ID</h4>
				</div>
				<div class="modal-body">
					<!-- <span id="alert_action"></span> -->
					<input type="text" name="invoice" id="invoice" class="form-control">
				</div>
				<div class="modal-footer">
					<button type="submit" name="save_invoice" class="btn btn-success active" data-dismiss="model">Print</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>

		</div>
	</div>
</form>
<!-- close model -->
<div id="orderModal" class="modal fade">

	<div class="modal-dialog">
		
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"><i class="fa fa-plus"></i> Create Order</h4>
				<input type="hidden" name="p_amount" id="p_amount">
				<input type="hidden" name="pro_id" id="pro_id">
				<input type="hidden" name="total" id="total">
				<input type="hidden" name="tax" id="tax" value="18" class="tax">
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>Enter Receiver Name</label>
							<input type="text" name="inventory_order_name" id="inventory_order_name" class="form-control" required />
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Date</label>
							<input type="text" name="inventory_order_date" id="inventory_order_date" class="form-control" required />
						</div>
					</div>
				</div>
				<div class="form-group">
					<label>Enter Receiver Address</label>
					<textarea name="inventory_order_address" id="inventory_order_address" class="form-control" required></textarea>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label>Select Category</label>
						<select id="category_id" class="form-control">
							<option>Select</option>
							<?php echo fill_category_list($connect);?>
						</select>
					</div>
					<div class="col-md-6">
						<label>Select Brand</label>
						<select name="brand_id" id="brand_id" class="form-control" required>
							<option value="">Select Brand</option>
						</select>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-6">
						<label>Select Product</label>
						<select id="product_id" class="form-control">
							<option value=""> Select Product</option>
						</select>
					</div>
					<div class="col-md-6">
						<label>Enter Quantity</label>
						<input type="text" name="qty" id="qty" class="form-control">
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<center><input type="button" name="add_btn" id="add_btn" class="btn btn-success btn-sm" value="+"></center>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<div class="table table-responsive">
							<table id="add_tab" class="table table-bordered">
								<tr>
									<td>#</td>
									<td>Pro_ID</td>
									<td>Product</td>
									<td>Quantity</td>
									<td>amount</td>
									<td>Remove</td>
								</tr>

							</table>
							<table class="table table-bordered" id="sumt">
								<tr>
									<td style="width: 70%">Grand Total</td>
									<td style="widows: 40%" id="sub_total"><input type="text" name="grand_total" id="grand_total" style="border: none"></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">

					</div>
				</div>
				<div class="form-group">
					<label>Select Payment Status</label>
					<select name="payment_status" id="payment_status" class="form-control">
						<option value="cash">Cash</option>
						<option value="credit">Credit</option>
					</select>
				</div>
			</div>
			<div class="modal-footer">

				<input type="hidden" name="inventory_order_id" id="inventory_order_id" />
				<input type="hidden" name="btn_action" id="btn_action" value="Add" />
				<input type="button" name="action" id="action" class="btn btn-info" value="Add" />
			</div>
		</div>
		
	</div>

</div>

<div class="modal fade" id="viewModal" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">VIEW DETAIL</h4>
			</div>
			<div class="modal-body">
				<div class="table table-responsive">
					<table class="table">
						<tr style="height: 50px">
							<td>Order-ID</td>
							<td class="order_id"></td>
						</tr>
						<tr style="height: 50px">
							<td>Customer Name</td>
							<td class="cusname"></td>
						</tr>
						<tr style="height: 50px">
							<td>Total Amount</td>
							<td class="total_amount"></td>
						</tr>
						<tr style="height: 50px">
							<td>Payment Status</td>
							<td class="payment"></td>
						</tr>
						<tr style="height: 50px">
							<td>Order Status</td>
							<td class="order_status"></td>
						</tr>
						<tr style="height: 50px">
							<td>Order Date</td>
							<td class="order_date"></td>
						</tr>
						<tr style="height: 50px">
							<td>Created By</td>
							<td class="created_by"></td>
						</tr>

						<tr style="height: 50px">
							<td>Product</td>
							<td class="product_view"></td>
						</tr>
						<tr style="height: 50px">
							<td>Quantity</td>
							<td class="quantity"></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>
<script type="text/javascript" src="order.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		load_data();
		$('#print_by').click(function(){

			$('#myModal').modal();
		});




		$(document).on('click','.view',function(){
			
			var viewdata=$(this).attr("id");
			var btn_action='view_id';
			$.ajax({
				url:"order_action.php",
				method:"POST",
				data:{btn_action:btn_action,viewdata:viewdata},
				dataType:"json",
				success:function(data)
				{
					$('#viewModal').modal();
					$('.order_id').html(viewdata);
					$('.cusname').html(data.customer);
					$('.total_amount').html(data.total_amt);
					$('.payment').html(data.payment_status);
					$('.order_status').html(data.order_status);
					$('.order_date').html(data.order_date);
					$('.created_by').html(data.created);
					$('.product_view').html(data.brand_n+"   "+data.product_n);
					$('.quantity').html(data.qty1);
				}
			});
		});

		$(document).on('click','#serch',function(){
			//alert('data');
			var f_date=$('#f_date').val();
			var to_date=$('#to_date').val();
			if(f_date!='' && to_date!='')
			{
				load_data(f_date);
				load_data(to_date);
			}
			else
			{
				load_data();
			}
		});
	});

	function load_data(view)
	{
		
		$.ajax({
			url:"total_order_action.php",
			type:"POST",
			data:{"view":view},
			success:function(data)
			{
				$('#fetch_data').html(data);
			}
		});
	}
</script>